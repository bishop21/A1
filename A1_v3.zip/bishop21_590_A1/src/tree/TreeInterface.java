package tree;

public interface TreeInterface {
	void addNode(CharLenPair clp);
}
