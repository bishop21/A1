package tree;

public interface CharLenPairInterface {
	void insertNode(CharLenPair clp);
}
